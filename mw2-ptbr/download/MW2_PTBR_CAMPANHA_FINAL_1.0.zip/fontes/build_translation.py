from pathlib import Path
import csv, json, re, hashlib, collections

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
PAT = re.compile(r'^REFERENCE\s+(\S+)\s*\r?\nLANG_ENGLISH\s+"((?:[^"\\]|\\.)*)"', re.M)
def decode(s):
    return re.sub(r'\\([nrt"\\])', lambda m: {'n':'\n','r':'\r','t':'\t','"':'"','\\':'\\'}[m[1]], s)
def encode(s):
    return s.replace('\\','\\\\').replace('"','\\"').replace('\n','\\n').replace('\r','\\r').replace('\t','\\t')
def parse(p):
    pairs=PAT.findall(p.read_text(encoding='cp1252'))
    assert len(pairs)==len(set(k for k,v in pairs)), p
    return {k:decode(v) for k,v in pairs}
def tsv(p):
    d={}
    for i,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
        k,v=line.split('\t',1)
        assert k not in d, (p,i,k)
        d[k]=decode(v)
    return d
def tokens(s):
    return collections.Counter(re.findall(r'&&\d+|\[\{[^}]+\}\]|\^[0-9]|%(?:\d+\$)?[sdiuf]',s))

from inventory import parse
sources=json.loads((WORK/'audit/inventory_all.json').read_text())
original_patch=parse(WORK/'audit/extracted/patch(1)/english/localizedstrings/patch(1).str')
translated={}
categories={}
for group in ['menus','hud','dialogue','credits','weapons','menus_extra','shared','keys']:
    for k,v in tsv(ROOT/'translations'/f'{group}.tsv').items():
        assert k in sources, ('unknown key',k)
        if k in translated:
            assert translated[k]==v, ('conflicting translation',k,translated[k],v)
            continue
        assert tokens(sources[k])==tokens(v), ('tokens changed',k,tokens(sources[k]),tokens(v))
        translated[k]=v;categories[k]=group
selected=json.loads((WORK/'audit/menu_selection.json').read_text())
assert set(selected)<=set(translated), ('missing selected menus',set(selected)-set(translated))

with (WORK/'audit/extracted/common/video/subtitles.csv').open(encoding='cp1252',newline='') as f:
    rows=list(csv.reader(f))
video_trans={int(k):v for k,v in tsv(ROOT/'translations/videos.tsv').items()}
reverse=collections.defaultdict(list)
for k,v in sources.items():
    if k.startswith('VIDSUBTITLES_'):reverse[v.strip()].append(k)
reviewed=[]
for i,row in enumerate(rows):
    assert len(row)==4,(i,len(row))
    text=row[3]
    blank=not re.sub(r'\^[0-9]','',text).strip()
    assert blank or i in video_trans,('untranslated video row',i)
    if blank:
        reviewed.append({'row':i,'video':row[0],'status':'empty_preserved'})
        continue
    new=video_trans[i]
    assert tokens(text)==tokens(new),('video tokens',i)
    keys=reverse[text.strip()]
    assert keys,('video localize not matched',i)
    for k in keys:
        if k in translated:assert translated[k]==new
        translated[k]=new;categories[k]='video_subtitles'
    # CSV loader trims leading blank lines. Keep stringed rendering intact,
    # normalize only the CSV cell before building for exact read-back checks.
    row[3]=new.lstrip('\r\n')
    reviewed.append({'row':i,'video':row[0],'keys':keys,'original':text,'ptbr':new,'status':'reviewed'})

merged=dict(original_patch);merged.update(translated)
str_out='VERSION "1"\nCONFIG ""\nFILENOTES "MW2 PT-BR projeto novo; campanha; textos revisados; validacao em jogo pendente"\n\n'
for k,v in merged.items():
    assert '\x00' not in v
    v.encode('cp1252')
    key='"'+encode(k)+'"'
    str_out+=f'REFERENCE {key}\nLANG_ENGLISH "{encode(v)}"\n\n'
str_out+='ENDMARKER\n'
(ROOT/'build/english/localizedstrings/ptbr_patch.str').write_bytes(str_out.encode('cp1252'))
(ROOT/'build/video').mkdir(exist_ok=True)
with (ROOT/'build/video/subtitles.csv').open('w',encoding='cp1252',newline='') as f:
    csv.writer(f,lineterminator='\n').writerows(rows)
zone=(WORK/'audit/extracted/patch(1)/zone_source/patch(1).zone').read_text()
zone=zone.replace('localize,patch(1)','localize,ptbr_patch')+'\nstringtable,video/subtitles.csv\n'
(ROOT/'zone_source/patch.zone').write_text(zone)
(ROOT/'expected_strings.json').write_text(json.dumps(merged,ensure_ascii=False,indent=2))
report={'status':'expanded_campaign_texts_runtime_validation_pending','source_entries':len(sources),'selected_menu_entries':len(selected),'reviewed_entries':len(translated),'changed_entries':sum(v!=sources[k] for k,v in translated.items()),'categories':dict(collections.Counter(categories.values())),'video_rows':len(rows),'video_reviewed_text_rows':len(video_trans),'video_empty_rows':len(rows)-len(video_trans),'entries':[{'key':k,'category':categories[k],'original':sources[k],'ptbr':v,'changed':v!=sources[k],'review':'contextual_manual'} for k,v in translated.items()],'videos':reviewed}
(ROOT/'coverage.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ['entries','videos']},ensure_ascii=False,indent=2))
