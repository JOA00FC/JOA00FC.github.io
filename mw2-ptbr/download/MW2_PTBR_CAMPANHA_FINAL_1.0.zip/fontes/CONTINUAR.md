# Continuidade deste projeto novo

Este material foi produzido a partir dos originais enviados nesta conversa. Não incorpora traduções ou scripts de tentativas antigas.

Pipeline efetivamente utilizado para a versão 0.2:
1. `inventory.py` lê os STR extraídos por OAT 0.34.0 e produz o inventário por zona/único.
2. `compile_dialogue.py` e `translate_labels.py` consolidam os arquivos revisados de `translations`. Os demais TSV foram revisados diretamente.
3. `build_translation.py` coleta os TSV, verifica tokens e gera coverage.json e a tabela CSV de vídeos. **O patch global grande que esse script gera como intermediário NÃO é distribuído nem usado na 0.2.** Ele duplicaria muitas entradas e pode ultrapassar o limite de localize. Não instalá-lo.
4. `build_full.py` substitui localize em cada zona proprietária e a tabela de vídeos em common, reutilizando os recursos carregados dos próprios originais. Referências externas são calculadas a partir de common/code_post_gfx, normalizando linhas asset,,nome para não excluir recursos próprios dos mapas.
5. `verify_full.py` reextrai e compara valores e chaves, inventários e todos os arquivos exportados exceto image/xmodel/xanim. `check_geometry.py` compara adicionalmente modelos/animações de common e trainer.
6. `package_full.py` cria deltas COPY/ADD sobre os fluxos descomprimidos dos originais. O codec verifica que cada delta reproduz exatamente o fluxo reconstruído validado. O arquivo patch.ff da 0.1 é restaurado ao original; localization.txt é mantido traduzido.
7. `test_full_installer.py` cobre falhas, reversão e recusas com fixtures; `test_real_install.py` testa a atualização real da 0.1, idempotência, verificação e restauração dos 24 arquivos. `archive_full.py` gera o ZIP e as somas de integridade.

Para reproduzir, são necessários os originais exatos, as extrações OAT, as ferramentas e a estrutura de diretórios de trabalho. Esses originais e binários de ferramenta não estão neste ZIP compacto. Não basta executar os scripts isoladamente na pasta fontes. O instalador do celular não precisa de nada disso: utiliza apenas o ZIP e a instalação original correspondente.

Limitações abertas: validação de todas as missões no aparelho; textos gráficos/IWI/vídeos; classificação exaustiva das chaves restantes e textos dinâmicos/hardcoded. Não marcar campaign_complete=true sem resolver essas pendências e registrar evidências.
