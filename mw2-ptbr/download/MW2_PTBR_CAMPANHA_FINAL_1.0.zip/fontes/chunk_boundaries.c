#include <stdint.h>
#include <stddef.h>
size_t boundaries(const unsigned char *data,size_t n,size_t *out){
 uint64_t gear[256],x=0x9e3779b97f4a7c15ULL;
 for(int i=0;i<256;i++){x^=x>>12;x^=x<<25;x^=x>>27;gear[i]=x*2685821657736338717ULL;}
 size_t count=0,start=0;uint64_t h=0;
 for(size_t i=0;i<n;i++){h=(h<<1)+gear[data[i]];size_t size=i+1-start;
 if(size>=128&&((h&511)==0||size>=4096)){out[count++]=i+1;start=i+1;h=0;}}
 if(start<n)out[count++]=n;return count;
}
