from pathlib import Path
import json,zipfile,hashlib,shutil
P=Path(__file__).resolve().parent;D=P/'full_package';B=P/'full'
results=[json.loads(f.read_text()) for f in sorted((B/'logs').glob('*_validation.json'))]
assert len(results)==22 and all(r['status']=='pass' for r in results)
assert len(json.loads((D/'manifest.json').read_text())['files'])==24
for r in results:assert 'Finished with 0 warnings, 0 errors' in (B/'logs'/f'{r["zone"]}.log').read_text()
validation={'fastfiles':results,'zone_count':len(results),'nonlocalize_compared_files':sum(r['compared_nonlocalize_files'] for r in results),'models_animations_sample':json.loads((B/'geometry_validation.json').read_text()),'localize_entry_count_preserved_in_every_zone':True,'localize_keys_and_values_match_expected_after_reextraction':True,'all_deltas_reconstruct_verified_raw_stream_exactly':True,'in_game_this_version':False,'images_iwi_not_redesigned':True,'structural_note':'OAT promove dependências internas para entradas explícitas: o total do cabeçalho pode aumentar. O inventário lógico foi comparado e preservado; isso não constitui teste em jogo.'}
(D/'VALIDACAO.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2))
fixture=json.loads((P/'fixture_results.json').read_text());full=json.loads((P/'full_install_results.json').read_text()) if (P/'full_install_results.json').exists() else ['Teste integral do ZIP: pendente nesta geração intermediária.']
(D/'TESTES.txt').write_text('\n'.join(fixture+full)+'\n\nExecutados em Linux/Python. A versão 0.1 foi confirmada pelo usuário no aparelho. Esta versão ampliada não foi executada no jogo neste ambiente.\n')
for f in (B/'logs').glob('*.log'):shutil.copyfile(f,D/'fontes'/f.name)
for name in ['test_full_installer.py','archive_full.py','test_real_install.py']:
 if (P/name).exists():shutil.copyfile(P/name,D/'fontes'/name)
for f in (B/'logs').glob('*_validation.json'):shutil.copyfile(f,D/'fontes'/f.name)
sums=[]
for f in sorted(D.rglob('*')):
 if f.is_file() and '__pycache__' not in f.parts and f.name!='SHA256SUMS.txt':sums.append(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.relative_to(D).as_posix())
(D/'SHA256SUMS.txt').write_text('\n'.join(sums)+'\n')
z=P/'MW2_PTBR_CAMPANHA_0.2.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as out:
 for f in sorted(D.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts:out.write(f,f.relative_to(D).as_posix())
with zipfile.ZipFile(z) as f:assert f.testzip() is None
print('ZIP',z.stat().st_size,hashlib.sha256(z.read_bytes()).hexdigest(),flush=True)
