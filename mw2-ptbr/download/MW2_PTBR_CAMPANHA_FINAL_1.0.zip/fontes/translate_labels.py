from pathlib import Path
import json,re
P=Path(__file__).parent/'translations'
r=json.loads((P/'weapon_source.json').read_text())
exact={
'&&1 - Camo':'&&1 - Camuflagem','RPG Launcher':'Lançador de RPG','One Man Army':'Exército de um homem','G36 LMG':'Metralhadora G36','Frag Grenade':'Granada de fragmentação','Care Package Marker':'Marcador de pacote de apoio','SEMTEX':'SEMTEX','Press forward to zoom':'Avance para ampliar','Emergency Airdrop Marker':'Marcador de entrega de emergência','Stun Grenade':'Granada de concussão','Riot Shield':'Escudo antimotim','Silencer':'Silenciador','Scavenger':'Catador','Ice Picks':'Picaretas de gelo','Shotguns':'Escopetas','Frag':'Fragmentação','Throwing Knife':'Faca de arremesso','Press ^3 &&1 ^7to refill your ammo':'Pressione ^3 &&1 ^7para reabastecer a munição','Press and hold^3 &&1 ^7to pickup Claymore Mines':'Segure^3 &&1 ^7para pegar minas Claymore','Sentry Gun':'Torreta automática','Not Enough Room To Fire':'Espaço insuficiente para disparar','Cook-Off':'Preparar granada','No Equipment Available':'Nenhum equipamento disponível','Grenade Launcher':'Lança-granadas','No Weapon Available':'Nenhuma arma disponível','Woodland':'Floresta','Blue Tiger':'Tigre azul','Default Weapon':'Arma padrão','Lock-On Required':'É preciso travar no alvo','ACOG Scope':'Mira ACOG','Gold Desert Eagle':'Desert Eagle dourada','Smoke Grenade':'Granada de fumaça','No Camo':'Sem camuflagem','No &&1 Ammo Remaining':'Sem munição de &&1','Golden':'Dourada','ANM8 Smoke Grenade':'Granada de fumaça ANM8','Knife':'Faca','Sub Machine Guns':'Submetralhadoras','Sentry Airdrop Marker':'Marcador de entrega de torreta','Binoculars':'Binóculos','Select a location':'Selecione um local','M2 Frag Grenade':'Granada de fragmentação M2','Too Close to Target':'Muito perto do alvo','Desert':'Deserto','Hold-Pin':'Segurar pino','Red Dot Sight':'Mira de ponto vermelho','No Ammo':'Sem munição','Claymore Detonator':'Detonador de Claymore','Flash Grenade':'Granada de luz','Assault Rifles':'Fuzis de assalto','C4 Detonator':'Detonador de C4','Sniper Rifles':'Fuzis de precisão','Red Tiger':'Tigre vermelho','Tactical Insertion':'Inserção tática','MK1 Frag Grenade':'Granada de fragmentação MK1','No Frag Grenades Remaining':'Sem granadas de fragmentação','Press and hold^3 &&1 ^7to use the M82 .50 Caliber Sniper Rifle':'Segure^3 &&1 ^7para usar o fuzil de precisão M82 calibre .50','Smoke':'Fumaça','Grip':'Empunhadura','No Attachment':'Sem acessório','No Special Grenades Remaining':'Sem granadas especiais','Prestige':'Prestígio','Sentry MiniGun':'Minigun automática',
'Silenced ACR with Heartbeat Sensor':'ACR (silenciador, sensor cardíaco)',
}
mods={
'Grenadier w/ Holographic':['lança-granadas','mira holográfica'],
'Grenadier w/ Red Dot Sight':['lança-granadas','mira de ponto vermelho'],
'Grenadier w/ ACOG Sight':['lança-granadas','ACOG'],
'Grenadier ACOG Sight':['lança-granadas','ACOG'],
'Grenadier Holographic':['lança-granadas','mira holográfica'],
'Shotgun w/ Heartbeat Sensor':['escopeta','sensor cardíaco'],
'Shotgun Heartbeat & Silenced':['escopeta','sensor cardíaco','silenciador'],
'Silenced Red Dot':['silenciador','mira de ponto vermelho'],
'Silenced Thermal Sight':['silenciador','mira térmica'],
'Scoped Silenced':['luneta','silenciador'],
'Silenced ACOG Sight':['silenciador','ACOG'],
'Red Dot Sight w/ Shotgun':['mira de ponto vermelho','escopeta'],
'Heartbeat Sensor':['sensor cardíaco'],'Extended Mags':['carregador ampliado'],'Red Dot Sight':['mira de ponto vermelho'],'ACOG Sight':['ACOG'],'Thermal Sight':['mira térmica'],'Tactical Knife':['faca tática'],'Grenade Launcher':['lança-granadas'],'Grenade Laucher':['lança-granadas'],'Explosive Rounds':['munição explosiva'],'Sonic Boom':['Onda de choque'],'Rapid Fire':['tiro rápido'],'Mars Sight':['mira MARS'],'w/ Shotgun':['escopeta'],'Silenced':['silenciador'],'Suppressed':['silenciador'],'Silencer':['silenciador'],'Thermal':['mira térmica'],'Holographic':['mira holográfica'],'Foregrip':['empunhadura'],'Scoped':['luneta'],'Scope':['luneta'],'Heartbeat':['sensor cardíaco'],'Grenadier':['lança-granadas'],'Bling':['acessórios duplos'],'Akimbo':['duplas'],'Lock-on':['travamento'],'FMJ':['munição encamisada'],'(Burst)':['rajada'],'Red Dot':['mira de ponto vermelho'],'Shotgun':['escopeta'],'ACOG':['ACOG']}
pat=re.compile('|'.join(re.escape(x) for x in sorted(mods,key=len,reverse=True)))
out=[]
for k,v in r:
 if v in exact:new=exact[v]
 else:
  parts=[]
  def sub(m):parts.extend(mods[m[0]]);return ''
  base=' '.join(pat.sub(sub,v).split())
  new=base+(' ('+', '.join(parts)+')' if parts else '')
 out.append((k,new))
(P/'weapons.tsv').write_text(''.join(k+'\t'+v+'\n' for k,v in out))
print('weapons',len(out),'changed',sum(a[1]!=b[1] for a,b in zip(r,out)))
