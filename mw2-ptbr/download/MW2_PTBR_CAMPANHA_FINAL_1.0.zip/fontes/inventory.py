from pathlib import Path
import re,json,collections
W=Path(__file__).resolve().parent.parent
pat=re.compile(r'^REFERENCE[^\S\n]+(.+?)\s*\nLANG_ENGLISH\s+"((?:[^"\\]|\\.)*)"',re.M)
def dec(s):return re.sub(r'\\([nrt"\\])',lambda m:{'n':'\n','r':'\r','t':'\t','"':'"','\\':'\\'}[m[1]],s)
def parse(p):
 text=p.read_text(encoding='cp1252');pairs=pat.findall(text)
 assert len(pairs)==len(re.findall('^REFERENCE',text,re.M)),p
 d={}
 for k,v in pairs:
  if k.startswith('"') and k.endswith('"'):k=dec(k[1:-1])
  assert k not in d,(p,k)
  d[k]=dec(v)
 return d
if __name__=='__main__':
 all={};zones={};conflicts=[]
 for p in sorted((W/'audit/extracted').rglob('*.str')):
  d=parse(p);zones[p.stem]=d
  for k,v in d.items():
   if k in all and all[k]!=v:conflicts.append([p.stem,k,all[k],v])
   all[k]=v
 (W/'audit/inventory_zones.json').write_text(json.dumps(zones,ensure_ascii=False,indent=2))
 (W/'audit/inventory_all.json').write_text(json.dumps(all,ensure_ascii=False,indent=2))
 (W/'audit/inventory_conflicts.json').write_text(json.dumps(conflicts,ensure_ascii=False,indent=2))
 print({k:len(v) for k,v in zones.items()}); print('UNIQUE',len(all),'CONFLICTS',len(conflicts))
 print(conflicts[:10])
