from pathlib import Path
import subprocess,tempfile,json,os,hashlib,zipfile,sys
P=Path(__file__).resolve().parent;W=P.parent;z=P/'MW2_PTBR_CAMPANHA_0.2.zip';m=json.loads(zipfile.ZipFile(z).read('manifest.json'));results=[]
def h(p):
 x=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):x.update(b)
 return x.hexdigest()
with tempfile.TemporaryDirectory(prefix='real-install-',dir=P) as td:
 game=Path(td)/'Jogo com espaços';game.mkdir()
 for rel in set(m['files'])|set(m['required_originals']):
  if rel.startswith('zone/english/'):
   n=Path(rel).name;n={'patch.ff':'patch(1).ff','code_post_gfx.ff':'code_post_gfx(1).ff'}.get(n,n);src=W/'original_zone'/n
  else:src=W/'audit'/rel
  p=game/rel;p.parent.mkdir(parents=True,exist_ok=True);os.link(src,p)
 def run(archive,action):
  r=subprocess.run([sys.executable,str(archive),'--game',str(game),'--action',action],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  print(r.stdout,flush=True);assert r.returncode==0,(action,r.stdout)
 run(P/'MW2_PTBR_CAMPANHA_0.1.zip','install')
 backup=game/'MW2_PTBR_BACKUP_01';old={str(f.relative_to(backup)):h(f) for f in backup.rglob('*') if f.is_file()}
 run(z,'install');results.append('ZIP real: atualização da 0.1 para 0.2 com os 24 arquivos da instalação fornecida: passou')
 assert all(h(backup/r)==v for r,v in old.items());results.append('ZIP real: todos os backups e metadados preexistentes da 0.1 preservados byte a byte: passou')
 run(z,'install');results.append('ZIP real: reinstalação idempotente: passou')
 run(z,'verify');results.append('ZIP real: verificação integral dos arquivos reconstruídos e backups: passou')
 run(z,'restore');assert all(h(game/r)==info['original_sha256'] for r,info in m['files'].items());results.append('ZIP real: restauração byte a byte de todos os 24 originais: passou')
 assert all(h(backup/r)==info['original_sha256'] for r,info in m['files'].items());results.append('ZIP real: backups íntegros após restaurar: passou')
(P/'full_install_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print('\n'.join(results),flush=True)
