from pathlib import Path
import tempfile,zipfile,json,hashlib,zlib,subprocess,sys,importlib.util,os
from delta_codec import create
P=Path(__file__).resolve().parent;D=P/'full_package'
def sha(b):return hashlib.sha256(b).hexdigest()
results=[]
with tempfile.TemporaryDirectory(dir=P) as folder:
 t=Path(folder);g=t/'Jogo com espaços';(g/'zone/english').mkdir(parents=True)
 exe=b'exe fixture';(g/'iw4sp.exe').write_bytes(exe)
 raw=b'TEXT ORIGINAL\0'+b'abc'*15000;new=b'TEXTO TRADUZIDO\0'+b'abc'*15000
 header=b'IWffu100'+bytes(13);orig=header+zlib.compress(raw);delta=create(raw,new);text=b'original localization';translated=b'localizacao'
 files={'zone/english/common.ff':{'kind':'delta','original_sha256':sha(orig),'original_size':len(orig),'payload':'payload/common.delta','payload_sha256':sha(delta),'header':header.hex(),'raw_size':len(new),'raw_sha256':sha(new)},'localization.txt':{'kind':'literal','original_sha256':sha(text),'original_size':len(text),'payload':'payload/localization.txt','payload_sha256':sha(translated),'target_sha256':sha(translated),'accepted_previous_sha256':[sha(b'0.1'),sha(translated)]}}
 m={'files':files,'required_originals':{'iw4sp.exe':sha(exe)}};z=t/'fixture.zip'
 def archive(corrupt=False):
  with zipfile.ZipFile(z,'w') as out:
   out.write(D/'__main__.py','__main__.py');out.write(D/'delta_codec.py','delta_codec.py');out.writestr('manifest.json',json.dumps(m));out.writestr('payload/common.delta',delta+(b'x' if corrupt else b''));out.writestr('payload/localization.txt',translated)
 def reset():
  (g/'zone/english/common.ff').write_bytes(orig);(g/'localization.txt').write_bytes(text)
 def run(action,code=0):
  r=subprocess.run([sys.executable,str(z),'--game',str(g),'--action',action],capture_output=True,text=True);assert r.returncode==code,(r.stdout,r.stderr);return r
 archive();reset();run('install');run('verify');run('install');run('restore');assert (g/'zone/english/common.ff').read_bytes()==orig and (g/'localization.txt').read_bytes()==text;results.append('Fixture: instalação limpa, idempotência, verificação e restauração exata: passou')
 (g/'localization.txt').write_bytes(b'0.1');backup=g/'MW2_PTBR_BACKUP_01/localization.txt';h=sha(backup.read_bytes());run('install');assert sha(backup.read_bytes())==h;run('restore');results.append('Fixture: atualização reconhecida sem alterar backup: passou')
 (g/'localization.txt').write_bytes(b'unknown');run('install',1);assert (g/'localization.txt').read_bytes()==b'unknown';reset();results.append('Fixture: recusa de base divergente sem gravação: passou')
 archive(True);run('install',1);assert (g/'zone/english/common.ff').read_bytes()==orig;archive();results.append('Fixture: rejeição de delta adulterado antes de gravar: passou')
 spec=importlib.util.spec_from_file_location('installer',D/'__main__.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);real=mod.prepare_file;count=[0]
 def fail_second(*args):
  count[0]+=1
  if count[0]==2:raise OSError('Falha simulada')
  return real(*args)
 mod.prepare_file=fail_second
 try:mod.install(g,mod.Package(z))
 except OSError:pass
 else:raise AssertionError('Falha não ocorreu')
 assert (g/'zone/english/common.ff').read_bytes()==orig and (g/'localization.txt').read_bytes()==text;results.append('Fixture: reversão após falha no segundo arquivo: passou')
 mod.prepare_file=real;run('install')
 assert mod.state(g/'localization.txt',files['localization.txt'])=='ptbr';results.append('Fixture: conteúdo idêntico entre versões identificado como PT-BR atual: passou')
 realcopy=mod.copy_atomic;count=[0]
 def fail_restore(*args):
  count[0]+=1
  if count[0]==2:raise OSError('Falha simulada na restauração')
  return realcopy(*args)
 mod.copy_atomic=fail_restore
 try:mod.restore(g,mod.Package(z))
 except OSError:pass
 else:raise AssertionError('Falha não ocorreu')
 assert mod.matches(g/'zone/english/common.ff',files['zone/english/common.ff']) and mod.matches(g/'localization.txt',files['localization.txt']);results.append('Fixture: reversão de restauração interrompida por erro: passou')
 run('restore');(g/'MW2_PTBR_BACKUP_01/localization.txt').write_bytes(b'bad');run('install',1);results.append('Fixture: rejeição de backup adulterado: passou')
(P/'fixture_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print('\n'.join(results))
