from pathlib import Path
import json,zlib,hashlib,zipfile,shutil,sys
from delta_codec import create,apply
P=Path(__file__).resolve().parent;W=P.parent;B=P/'full';D=P/'full_package'
def sha(b):return hashlib.sha256(b).hexdigest()
cached=json.loads((D/'manifest.json').read_text()).get('files',{}) if (D/'manifest.json').exists() else {}
old=json.loads(zipfile.ZipFile(P/'MW2_PTBR_CAMPANHA_0.1.zip').read('manifest.json'))
m={'id':'mw2-pc-ptbr-campanha-0.2','status':'text_expansion_pending_full_runtime_validation','exe_version':'1.1.0.1525','files':{},'required_originals':{k:v for k,v in old['required_originals'].items() if k not in ['zone/english/common.ff','zone/english/code_post_gfx.ff']}}
for name in sorted(json.loads((W/'audit/inventory_zones.json').read_text())):
 if name=='patch(1)':continue
 n=name.replace('(1)','');path=B/'output'/f'{n}.ff';validation=B/'logs'/f'{n}_validation.json'
 if not validation.exists() or json.loads(validation.read_text())['status']!='pass':
  if '--partial' in sys.argv:print('Pending',n,flush=True);continue
  raise RuntimeError('Validação pendente: '+n)
 rel='zone/english/'+n+'.ff'
 if rel in cached and cached[rel]['reference_ff_sha256']==sha(path.read_bytes()) and sha((D/cached[rel]['payload']).read_bytes())==cached[rel]['payload_sha256']:
  m['files'][rel]=cached[rel];continue
 original=(W/'original_zone'/f'{name}.ff').read_bytes();new=path.read_bytes();source=zlib.decompress(original[21:]);target=zlib.decompress(new[21:])
 b=create(source,target);assert apply(source,b,len(target))==target
 payload='payload/'+n+'.delta';(D/payload).write_bytes(b)
 m['files']['zone/english/'+n+'.ff']={'kind':'delta','original_sha256':sha(original),'original_size':len(original),'payload':payload,'payload_sha256':sha(b),'header':new[:21].hex(),'raw_sha256':sha(target),'raw_size':len(target),'reference_ff_sha256':sha(new),'reference_ff_size':len(new)}
 print(n,'delta MB',round(len(zlib.compress(b,9))/1e6,2),flush=True)
for rel,original,new in [('zone/english/patch.ff',W/'original_zone/patch(1).ff',W/'original_zone/patch(1).ff'),('localization.txt',W/'audit/localization.txt',P/'package/files/localization.txt')]:
 b=new.read_bytes();payload='payload/'+new.name;(D/payload).write_bytes(b)
 m['files'][rel]={'kind':'literal','original_sha256':sha(original.read_bytes()),'original_size':original.stat().st_size,'payload':payload,'payload_sha256':sha(b),'target_sha256':sha(b),'accepted_previous_sha256':[old['files'][rel]['translated_sha256']]}
(D/'manifest.json').write_text(json.dumps(m,indent=2))
print('FILES',len(m['files']))
