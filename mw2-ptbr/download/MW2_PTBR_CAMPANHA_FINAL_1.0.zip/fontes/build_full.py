from pathlib import Path
import json,subprocess,concurrent.futures,csv,shutil,sys
from inventory import parse
P=Path(__file__).resolve().parent;W=P.parent;B=P/'full';E=W/'audit/extracted'
translated={x['key']:x['ptbr'] for x in json.loads((P/'coverage.json').read_text())['entries']}
zones=json.loads((W/'audit/inventory_zones.json').read_text())
def enc(s):return s.replace('\\','\\\\').replace('"','\\"').replace('\n','\\n').replace('\r','\\r').replace('\t','\\t')
Q=[str(W/'tools/i386/usr/bin/qemu-i386-static'),str(W/'tools/i386/usr/lib32/ld-linux.so.2'),'--library-path',str(W/'tools/i386/usr/lib32'),str(W/'tools/oat/Linker'),'--no-color']
for d in ['sources/assetlist','raw/english/localizedstrings','sources','output','logs','expected']:(B/d).mkdir(parents=True,exist_ok=True)
(B/'sources/assetlist/external_shells.csv').write_text('fx,shellejects/pistol_resting\nfx,shellejects/rifle_resting\n')
shutil.copytree(P/'build/video',B/'raw/video',dirs_exist_ok=True)
job=[]
for z,entries in zones.items():
 if z=='patch(1)':continue
 name=z.replace('(1)','');e={k:translated.get(k,v) for k,v in entries.items()}
 (B/'expected'/f'{name}.json').write_text(json.dumps(e,ensure_ascii=False))
 value='VERSION "1"\nCONFIG ""\nFILENOTES "PT-BR campaign"\n\n'+''.join(f'REFERENCE "{enc(k)}"\nLANG_ENGLISH "{enc(v)}"\n\n' for k,v in e.items())+'ENDMARKER\n'
 (B/'raw/english/localizedstrings'/f'{z}.str').write_bytes(value.encode('cp1252'))
 zone=(E/z/'zone_source'/f'{z}.zone').read_text()
 if z not in ['common','code_post_gfx(1)','iw4_credits']:
  own={line.replace(',,',',',1) for line in zone.splitlines()};external=set()
  for base in ['common','code_post_gfx(1)']:
   for line in (E/base/'zone_source'/f'{base}.zone').read_text().splitlines():
    if ',' in line and not line.startswith(('>','localize,')) and line.replace(',,',',',1) not in own:external.add(line)
  (B/'sources/assetlist'/f'external_{name}.csv').write_text('\n'.join(sorted(external))+'\n')
  zone+=f'\nignore,external_{name}\n'
 (B/'sources'/f'{name}.zone').write_text(zone)
 job.append((z,name))
def build(j):
 z,n=j
 with (B/'logs'/f'{n}.log').open('w') as out:
  r=subprocess.run(Q+['--load',str(W/'original_zone'/f'{z}.ff'),'--source-search-path',str(B/'sources'),'--asset-search-path',str(B/'raw'),'--output-folder',str(B/'output'),n],stdout=out,stderr=subprocess.STDOUT)
 log=(B/'logs'/f'{n}.log').read_text();print(n,r.returncode,log.splitlines()[-1],flush=True)
 return n,r.returncode
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:results=list(ex.map(build,[j for j in job if (len(sys.argv)>1 and j[1] in sys.argv[1:]) or (len(sys.argv)==1 and (not (B/'logs'/f'{j[1]}.log').exists() or 'Finished with 0 warnings, 0 errors' not in (B/'logs'/f'{j[1]}.log').read_text()))]))
 (B/'build_results.json').write_text(json.dumps(results));assert all(x[1]==0 for x in results)
