from pathlib import Path
import subprocess,json,hashlib,concurrent.futures,shutil,sys
from inventory import parse
P=Path(__file__).resolve().parent;W=P.parent;B=P/'full'
Q=[str(W/'tools/i386/usr/bin/qemu-i386-static'),str(W/'tools/i386/usr/lib32/ld-linux.so.2'),'--library-path',str(W/'tools/i386/usr/lib32'),str(W/'tools/oat/Unlinker'),'--no-color','--exclude-assets','image,xmodel,xanim']
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(z):
 name=z.replace('(1)','');log=(B/'logs'/f'{name}.log').read_text()
 if 'Finished with 0 warnings, 0 errors' not in log:return {'zone':name,'status':'blocked_build','last':log.splitlines()[-1]}
 for side,f in [('original',W/'original_zone'/f'{z}.ff'),('new',B/'output'/f'{name}.ff')]:
  target=B/f'check_{side}'
  with (B/f'check_{name}_{side}.log').open('w') as out:
   r=subprocess.run(Q+['--output-folder',str(target/'?zone?'),str(f)],stdout=out,stderr=subprocess.STDOUT)
  assert r.returncode==0,(name,side)
 aroot=B/'check_original'/z;broot=B/'check_new'/name
 a={f.relative_to(aroot).as_posix():f for f in aroot.rglob('*') if f.is_file()};b={f.relative_to(broot).as_posix():f for f in broot.rglob('*') if f.is_file()}
 # Project/zone name changes only for code_post_gfx(1).
 astr=next(aroot.rglob('*.str'));bstr=next(broot.rglob('*.str'))
 expected=json.loads((B/'expected'/f'{name}.json').read_text());assert parse(bstr)==expected,name
 excluded={astr.relative_to(aroot).as_posix(),bstr.relative_to(broot).as_posix(),f'zone_source/{z}.zone',f'zone_source/{name}.zone'}
 if name=='common':excluded.add('video/subtitles.csv')
 aset=set(a)-excluded;bset=set(b)-excluded
 missing=sorted(aset-bset);extra=sorted(bset-aset);diff=[k for k in sorted(aset&bset) if h(a[k])!=h(b[k])]
 # Asset ordering may vary, but inventory must not lose/add resources.
 az=set((aroot/'zone_source'/f'{z}.zone').read_text().splitlines());bz=set((broot/'zone_source'/f'{name}.zone').read_text().splitlines())
 az={x for x in az if ',' in x and not x.startswith('localize,')};bz={x for x in bz if ',' in x and not x.startswith('localize,')}
 result={'zone':name,'status':'pass' if not missing and not extra and not diff and az==bz else 'fail','localize_entries':len(expected),'compared_nonlocalize_files':len(aset),'missing':missing,'extra':extra,'changed':diff,'asset_inventory_added':sorted(bz-az),'asset_inventory_removed':sorted(az-bz),'excluded_asset_types':['image','xmodel','xanim']}
 print(name,result['status'],len(aset),'diff',len(diff),'extra',len(extra),flush=True)
 (B/'logs'/f'{name}_validation.json').write_text(json.dumps(result,indent=2));return result
if __name__=='__main__':
 zones=list(json.loads((W/'audit/inventory_zones.json').read_text()));zones.remove('patch(1)')
 if len(sys.argv)>1:zones=sys.argv[1:]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:results=list(ex.map(check,zones))
 (B/'validation_results.json').write_text(json.dumps(results,indent=2));assert all(r['status']=='pass' for r in results),[r['zone'] for r in results if r['status']!='pass']
