from pathlib import Path
import json,collections,shutil,re
P=Path(__file__).resolve().parent;W=P.parent;D=P/'full_package';B=P/'full'
r=json.loads((P/'coverage.json').read_text());src=json.loads((W/'audit/inventory_all.json').read_text());review={e['key']:e for e in r['entries']};startup=json.loads((P/'translations/startup.json').read_text())
missing=[]
for k,v in src.items():
 if k in review:continue
 if k.startswith(('SPECIAL_OPS_','COOP_','RANK_','SUBTITLE_SO','SUBTITLE_AC130')):reason='fora_do_escopo_modo_adicional'
 elif k.startswith('VIDSUBTITLES_') and not re.sub(r'\^[0-9]','',v).strip():reason='entrada_sem_texto_preservada'
 elif k.startswith('PAINTER_'):reason='ferramenta_interna_de_edicao'
 else:reason='nao_traduzido_compartilhado_legado_ou_modo_adicional_classificacao_nao_exaustiva'
 missing.append({'key':k,'original':v,'status':reason})
r.update({'status':'pacote_consolidado_de_textos_validacao_integral_em_jogo_pendente','startup_messages':startup,'total_reviewed_with_startup':len(review)+len(startup),'total_changed_with_startup':r['changed_entries']+len(startup),'untranslated_entries':missing,'campaign_complete':False,'in_game_tested_this_release':False,'prior_release_user_confirmed':True,'installation_strategy':'localize values replaced in their owning zones; no oversized overlay; 0.1 patch restored to original','excluded_visual_content':'Textos incorporados a imagens/IWI e quadros de vídeo não editados; apenas iw_00.iwd teve inventário interno nesta etapa. Não há comprovação de cobertura visual total.'})
(D/'RELATORIO_TEXTOS.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
(D/'COBERTURA.md').write_text(f'''# Cobertura — MW2 PC campanha PT-BR 0.2

Este é um pacote consolidado dos textos extraídos e revisados. **Não é uma certificação de tradução 100% completa nem de estabilidade em todas as missões.** A versão 0.1 funcionou no aparelho conforme informado pelo usuário; esta ampliação ainda precisa de validação dentro da campanha.

## Contagens comprovadas por chave

- {len(src):,} chaves únicas inventariadas nos FastFiles examinados, incluindo material de outros modos e conteúdo legado.
- {len(review):,} entradas de localização revisadas; {r['changed_entries']:,} têm texto diferente do original. Nomes próprios, modelos, números e símbolos podem permanecer iguais após revisão.
- Mais {len(startup)} mensagens de inicialização/erro revisadas em localization.txt.
- Total: **{len(review)+len(startup):,} entradas revisadas**, **{r['changed_entries']+len(startup):,} alteradas**.
- {len(missing):,} chaves não traduzidas listadas individualmente no relatório. Incluem modos fora do escopo, dados legados, ferramentas internas e entradas vazias. A classificação desse restante não é uma prova de que nenhuma delas possa aparecer na campanha.

Esses números não são uma porcentagem de toda a campanha e não equivalem à quantidade de falas efetivamente exibidas.

| Grupo revisado | Entradas |
|---|---:|
| Menus e opções (seleção inicial e complementos) | 810 |
| Instruções e HUD compartilhados | 207 |
| Legendas de diálogo, incluindo material legado | 2190 |
| Objetivos, comandos e títulos específicos dos mapas | 561 |
| Erros EXE e avisos de morte/citações | 249 |
| Créditos, com nomes próprios preservados | 866 |
| Armas e acessórios, incluindo variantes compartilhadas | 561 |
| Rótulos e mensagens compartilhados adicionais | 162 |
| Nomes de teclas e botões | 110 |
| Textos de legendas de vídeos | 175 |
| Mensagens de inicialização localization.txt | 21 |

As 192 linhas da tabela de vídeos mantêm identificadores e tempos: 175 linhas textuais revisadas e 17 entradas sem texto preservadas. Os áudios permanecem originais: esta tradução não é dublagem.

## Arquivos da campanha abrangidos

`code_post_gfx.ff`, `common.ff`, `iw4_credits.ff`, `trainer.ff`, `roadkill.ff`, `cliffhanger.ff`, `airport.ff`, `favela.ff`, `invasion.ff`, `favela_escape.ff`, `arcadia.ff`, `oilrig.ff`, `gulag.ff`, `contingency.ff`, `dcemp.ff`, `dcburning.ff`, `dc_whitehouse.ff`, `estate.ff`, `boneyard.ff`, `af_caves.ff`, `af_chase.ff`, `ending.ff`.

Todos permanecem em `zone/english`. `localization.txt` também é atualizado. O `patch.ff` da versão 0.1 é reposto ao original: os textos que estavam nele agora ficam nos arquivos que já os contêm, evitando duplicar milhares de entradas no limite interno do jogo.

## O que ainda não está comprovado/concluído

- Exibição correta, prioridade de carregamento, acentos, cortes de linha e estabilidade ao jogar **todas** as missões, inclusive carregar saves antigos, morrer/reiniciar e concluir a campanha.
- Textos desenhados em texturas IWI, placas, logotipos, imagens de carregamento e quadros dos vídeos: não foram redesenhados. O inventário de iw_00.iwd encontrou 1.426 imagens IWI e um CFG, mas não houve inspeção visual de todas elas nem inventário interno de todos os demais IWD.
- Eventuais textos montados dinamicamente, fixos em scripts, no executável ou em formatos não extraídos. O executável não foi modificado.
- A análise de referências de scripts cobre chaves literais; ela não detecta com certeza toda composição dinâmica de nomes.

## Garantias técnicas e limites

A compilação/reextração usa OpenAssetTools 0.34.0. As traduções preservam chaves, variáveis, comandos de interação e códigos de cor. A reconstrução altera a serialização dos FastFiles, embora o conteúdo não textual exportável seja comparado com o original. Consulte VALIDACAO.json e TESTES.txt para o escopo exato dos testes; eles não substituem jogar a campanha.

`RELATORIO_TEXTOS.json` contém original, PT-BR, revisão e estado de cada entrada revisada, além da lista não traduzida. `fontes` contém os textos e scripts deste projeto novo para continuidade e auditoria.
''',encoding='utf-8')
(D/'LEIA-ME.md').write_text('''# MW2 (2009) PC — campanha PT-BR 0.2

Pacote consolidado de textos. Consulte COBERTURA.md: a validação completa dentro do jogo e a tradução de textos incorporados a imagens permanecem pendentes. Não é uma versão final certificada como 100% completa.

## Instalar ou atualizar a 0.1

Feche o jogo. Baixe `MW2_PTBR_CAMPANHA_0.2.zip` para Download. No Termux, execute:

```sh
python ~/storage/downloads/MW2_PTBR_CAMPANHA_0.2.zip --game "/storage/emulated/0/X360/Call of Duty - Modern Warfare 2"
```

Escolha **1 — Instalar/atualizar**. Não precisa apagar ou restaurar a 0.1 antes. A aplicação pode levar vários minutos: mantenha o Termux aberto até aparecer **INSTALAÇÃO CONCLUÍDA**. O instalador informa cada arquivo processado.

O instalador verifica a base exata, conserva os backups originais da 0.1 e acrescenta os demais. Calcula o espaço necessário antes de escrever; reserve aproximadamente 4 GB livres adicionais para backup e arquivo temporário. Se faltar espaço, ele mostra o mínimo calculado. Não precisa de root, compilador, Wine nem ferramentas de extração no celular: apenas o Python que você já instalou.

O ZIP contém deltas binários e um aplicador. O Termux usa seus originais para reconstruir os arquivos e verifica os dados resultantes. **Não copie a pasta payload diretamente para o jogo.** Os deltas não são FastFiles prontos. O ZIP não inclui executáveis de jogo.

Se precisar configurar o Termux de novo:

```sh
termux-setup-storage
pkg install -y python
```

O idioma-base continua **English**, com a pasta `zone/english`. Ative **Legendas** nas opções.

## Restaurar e conferir

Execute o mesmo ZIP e escolha **2 — Restaurar originais** ou **3 — Verificar**. Os originais ficam em `MW2_PTBR_BACKUP_01` dentro do jogo; não apague essa pasta. Use este ZIP 0.2 para restaurar todos os arquivos da ampliação: o instalador antigo 0.1 conhece apenas dois arquivos.

Há verificação SHA-256 do pacote, originais, deltas e conteúdo reconstruído. Arquivos desconhecidos ou backups alterados são recusados. Falhas de gravação tratadas pelo instalador acionam reversão dos arquivos já gravados. Se o processo for encerrado abruptamente, mantenha o backup e execute novamente o instalador; ele reconhece originais e arquivos desta versão para concluir a aplicação. Não abra o jogo enquanto a atualização estiver incompleta.

Se você apagar o backup ou alterar manualmente os arquivos, a restauração automática pode ficar indisponível. Uma verificação de integridade pela Steam pode restaurar os originais e remover a tradução.

## O que conferir no jogo

- Menus, opções gráficas, áudio, controles, pausa e seleção de missões.
- Treinamento: legendas de Foley e Dunn, instruções de tiro, granadas e o Fosso.
- Demais missões: legendas de diálogos, comandos de interação, objetivos e nomes de armas.
- Vídeos de carregamento e créditos: textos traduzidos, nomes próprios preservados.
- Acentos, texto cortado, carregar save, reiniciar checkpoint e concluir missões.

Caso uma frase permaneça em inglês ou ocorra erro, registre a missão, a frase/tela e a mensagem de erro. O áudio continua em inglês. Textos que já fazem parte de uma imagem/vídeo não foram redesenhados.

Nenhum save, executável, driver, configuração gráfica ou de desempenho é instalado/modificado. A reconstrução usa recursos gráficos e scripts dos seus próprios arquivos, sem edição intencional desses conteúdos. O escopo de comparação técnica está em VALIDACAO.json.

Base específica: executável 1.1.0.1525 e hashes da instalação fornecida. A alegação de origem Steam/atualização foi informada pelo usuário; não é uma verificação independente de manifesto Steam.
''',encoding='utf-8')
s=D/'fontes';s.mkdir(exist_ok=True)
shutil.copytree(P/'translations',s/'translations',dirs_exist_ok=True)
for name in ['inventory.py','compile_dialogue.py','translate_labels.py','build_translation.py','build_full.py','verify_full.py','check_geometry.py','delta_codec.py','chunk_boundaries.c','package_full.py','make_reports.py']:
 shutil.copyfile(P/name,s/name)
for name in ['inventory_all.json','inventory_zones.json','inventory_conflicts.json','iw00_inventory.txt']:
 shutil.copyfile(W/'audit'/name,s/name)
for f in (B/'logs').glob('*_validation.json'):shutil.copyfile(f,s/f.name)
