import subprocess,concurrent.futures,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent;B=P/'full'
Q=[str(W/'tools/i386/usr/bin/qemu-i386-static'),str(W/'tools/i386/usr/lib32/ld-linux.so.2'),'--library-path',str(W/'tools/i386/usr/lib32'),str(W/'tools/oat/Unlinker'),'--no-color','--include-assets','xmodel,xanim','--model-format','XMODEL_BIN']
def one(job):
 z,side=job;f=(W/'original_zone'/f'{z}.ff') if side=='original' else (B/'output'/f'{z}.ff')
 with (B/f'geometry_{z}_{side}.log').open('w') as out:r=subprocess.run(Q+['--output-folder',str(B/f'geometry_{side}'/'?zone?'),str(f)],stdout=out,stderr=subprocess.STDOUT)
 print(z,side,r.returncode,flush=True);assert r.returncode==0
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:list(ex.map(one,[(z,s) for z in ['common','trainer'] for s in ['original','new']]))
result=[]
for z in ['common','trainer']:
 def files(side):
  p=B/f'geometry_{side}'/z
  return {str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file() and 'zone_source' not in f.parts}
 a=files('original');b=files('new');result.append({'zone':z,'files':len(a),'identical':a==b});assert a==b,(z,[k for k in a if a[k]!=b.get(k)][:10])
(B/'geometry_validation.json').write_text(json.dumps(result,indent=2));print(result)
