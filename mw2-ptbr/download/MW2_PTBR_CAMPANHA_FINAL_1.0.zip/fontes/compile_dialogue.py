from pathlib import Path
import json,re
P=Path(__file__).parent/'translations'
NAMES={'Captain':'Capitão','Helicopter Pilot':'Piloto do helicóptero','Crew Chief':'Chefe de tripulação','Pave Low Pilot':'Piloto do Pave Low','Little Bird Pilot':'Piloto do Little Bird','UAV Operator':'Operador de VANT','Sub Commander':'Comandante do submarino','TF-141 Soldier':'Soldado da FT-141','Shadow Company HQ':'QG da Shadow Company','Stryker Gunner':'Atirador do Stryker','Artillery Battery':'Bateria de artilharia','Evac Site':'Ponto de evacuação','SEAL Team Leader':'Líder da equipe SEAL','ISS Control':'Controle da ISS','Houston Command':'Comando de Houston','Colonel':'Coronel','NORAD HQ':'QG do NORAD','U.S. Soldiers':'Soldados dos EUA','(HQ Radio)':'(Rádio do QG)','Sgt.':'Sgt.','Cpl.':'Cb.','Pvt.':'Sd.','Capt.':'Cap.','Gen.':'Gen.','Pfc.':'Sd.','Lt.':'Ten.','General':'General','AC-130 FCO':'Oficial de tiro do AC-130','AC-130 TV Operator':'Operador de TV do AC-130','AC-130 Pilot':'Piloto do AC-130'}
result={}
for f in sorted(P.glob('*_pt.txt')):
 src=json.loads(f.with_name(f.stem[:-3]+'_source.json').read_text())
 lines=f.read_text().splitlines()
 assert len(lines)==len(src),(f,len(lines),len(src))
 for (k,v),pt in zip(src,lines):
  m=re.match(r'(\^[0-9])(.*?)(: \^7)(.*)',v,re.S)
  if m:
   name=m[2]
   for a,b in NAMES.items():name=name.replace(a,b)
   val=m[1]+name+m[3]+pt
  else:val=pt
  assert sorted(re.findall(r'\^[0-9]|&&\d+|\[\{.*?\}\]',v))==sorted(re.findall(r'\^[0-9]|&&\d+|\[\{.*?\}\]',val)),(k,v,val)
  result[k]=val
out=''.join(k+'\t'+v.replace('\n','\\n')+'\n' for k,v in result.items())
(P/'dialogue.tsv').write_text(out)
print('Dialogue entries',len(result))
