# Cobertura — MW2 PC campanha PT-BR FINAL 1.0

Versão final para o escopo de textos aceito pelo usuário em 04/11/2026. As imagens e os vídeos não serão recriados. O conteúdo instalado é idêntico ao da 0.2, cujo funcionamento o usuário confirmou. Não há novas frases traduzidas nesta consolidação; mudaram a identificação da entrega e a documentação. A verificação de todas as missões não está documentada. “Final” identifica esta entrega acordada, não uma certificação de 100% de todos os textos possíveis.

## Contagens comprovadas por chave

- 7,313 chaves únicas inventariadas nos FastFiles examinados, incluindo material de outros modos e conteúdo legado.
- 5,891 entradas de localização revisadas; 5,064 têm texto diferente do original. Nomes próprios, modelos, números e símbolos podem permanecer iguais após revisão.
- Mais 21 mensagens de inicialização/erro revisadas em localization.txt.
- Total: **5,912 entradas revisadas**, **5,085 alteradas**.
- 1,422 chaves não traduzidas listadas individualmente no relatório. Incluem modos fora do escopo, dados legados, ferramentas internas e entradas vazias. A classificação desse restante não é uma prova de que nenhuma delas possa aparecer na campanha.

Esses números não são uma porcentagem de toda a campanha e não equivalem à quantidade de falas efetivamente exibidas.

| Grupo revisado | Entradas |
|---|---:|
| Menus e opções (seleção inicial e complementos) | 810 |
| Instruções e HUD compartilhados | 207 |
| Legendas de diálogo, incluindo material legado | 2190 |
| Objetivos, comandos e títulos específicos dos mapas | 561 |
| Erros EXE e avisos de morte/citações | 249 |
| Créditos, com nomes próprios preservados | 866 |
| Armas e acessórios, incluindo variantes compartilhadas | 561 |
| Rótulos e mensagens compartilhados adicionais | 162 |
| Nomes de teclas e botões | 110 |
| Textos de legendas de vídeos | 175 |
| Mensagens de inicialização localization.txt | 21 |

As 192 linhas da tabela de vídeos mantêm identificadores e tempos: 175 linhas textuais revisadas e 17 entradas sem texto preservadas. Os áudios permanecem originais: esta tradução não é dublagem.

## Arquivos da campanha abrangidos

`code_post_gfx.ff`, `common.ff`, `iw4_credits.ff`, `trainer.ff`, `roadkill.ff`, `cliffhanger.ff`, `airport.ff`, `favela.ff`, `invasion.ff`, `favela_escape.ff`, `arcadia.ff`, `oilrig.ff`, `gulag.ff`, `contingency.ff`, `dcemp.ff`, `dcburning.ff`, `dc_whitehouse.ff`, `estate.ff`, `boneyard.ff`, `af_caves.ff`, `af_chase.ff`, `ending.ff`.

Todos permanecem em `zone/english`. `localization.txt` também é atualizado. O `patch.ff` da versão 0.1 é reposto ao original: os textos que estavam nele agora ficam nos arquivos que já os contêm, evitando duplicar milhares de entradas no limite interno do jogo.

## O que ainda não está comprovado/concluído

- Exibição correta, prioridade de carregamento, acentos, cortes de linha e estabilidade ao jogar **todas** as missões, inclusive carregar saves antigos, morrer/reiniciar e concluir a campanha.
- Textos desenhados em texturas IWI, placas, logotipos, imagens de carregamento e quadros dos vídeos: não foram redesenhados. A auditoria posterior inventariou os 32 IWD recebidos e encontrou 12.080 entradas IWI; 42 imagens de localized_english_iw00.iwd foram inspecionadas visualmente. Não houve inspeção visual de todas as imagens. Esses gráficos ficam fora desta entrega por decisão do usuário.
- Eventuais textos montados dinamicamente, fixos em scripts, no executável ou em formatos não extraídos. O executável não foi modificado.
- A análise de referências de scripts cobre chaves literais; ela não detecta com certeza toda composição dinâmica de nomes.

## Garantias técnicas e limites

A compilação/reextração usa OpenAssetTools 0.34.0. As traduções preservam chaves, variáveis, comandos de interação e códigos de cor. A reconstrução altera a serialização dos FastFiles, embora o conteúdo não textual exportável seja comparado com o original. Consulte VALIDACAO.json e TESTES.txt para o escopo exato dos testes; eles não substituem jogar a campanha.

`RELATORIO_TEXTOS.json` contém original, PT-BR, revisão e estado de cada entrada revisada, além da lista não traduzida. `fontes` contém os textos e scripts deste projeto novo para continuidade e auditoria.
