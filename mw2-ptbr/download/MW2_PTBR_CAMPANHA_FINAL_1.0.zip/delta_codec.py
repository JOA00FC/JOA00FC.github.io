"""Deltas binários COPY/ADD para fluxos FastFile. Decodificação só usa stdlib."""
import struct,zlib,hashlib
MAGIC=b'MW2D1\0'
def apply(source,delta,expected_size):
 if not delta.startswith(MAGIC):raise ValueError('Delta inválido')
 pos=len(MAGIC);out=bytearray()
 while pos<len(delta):
  op=delta[pos];pos+=1
  if op==0:
   offset,size=struct.unpack_from('<QI',delta,pos);pos+=12
   if offset+size>len(source):raise ValueError('Referência fora do original')
   out.extend(source[offset:offset+size])
  elif op==1:
   size=struct.unpack_from('<I',delta,pos)[0];pos+=4
   if pos+size>len(delta):raise ValueError('Delta truncado')
   out.extend(delta[pos:pos+size]);pos+=size
  else:raise ValueError('Operação desconhecida')
  if len(out)>expected_size:raise ValueError('Tamanho excessivo')
 if len(out)!=expected_size:raise ValueError('Tamanho final incorreto')
 return out

def create(source,target):
 import ctypes
 from pathlib import Path
 lib=ctypes.CDLL(str(Path(__file__).with_name('chunk_boundaries.so')))
 lib.boundaries.argtypes=[ctypes.c_char_p,ctypes.c_size_t,ctypes.POINTER(ctypes.c_size_t)];lib.boundaries.restype=ctypes.c_size_t
 def chunks(b):
  arr=(ctypes.c_size_t*(len(b)//128+2))();n=lib.boundaries(b,len(b),arr);start=0
  for end in arr[:n]:yield start,end;start=end
 idx={}
 for start,end in chunks(source):idx.setdefault(hashlib.blake2b(source[start:end],digest_size=16).digest(),(start,end))
 ops=[]
 for start,end in chunks(target):
  value=target[start:end];ref=idx.get(hashlib.blake2b(value,digest_size=16).digest())
  if ref and source[ref[0]:ref[1]]==value:
   a,b=ref
   if ops and ops[-1][0]==0 and ops[-1][1]+ops[-1][2]==a:ops[-1][2]+=b-a
   else:ops.append([0,a,b-a])
  else:
   if ops and ops[-1][0]==1:ops[-1][1].extend(value)
   else:ops.append([1,bytearray(value)])
 out=bytearray(MAGIC)
 for op in ops:
  if op[0]==0:out.extend(b'\0'+struct.pack('<QI',op[1],op[2]))
  else:out.extend(b'\1'+struct.pack('<I',len(op[1]))+op[1])
 return out
