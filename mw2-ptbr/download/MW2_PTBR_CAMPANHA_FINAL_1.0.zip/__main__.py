#!/usr/bin/env python3
"""MW2 campanha PT-BR: aplicação de deltas verificados; somente stdlib."""
import argparse,hashlib,json,os,shutil,sys,tempfile,zipfile,zlib
from pathlib import Path
from delta_codec import apply
BACKUP='MW2_PTBR_BACKUP_01'
LOCK='MW2_PTBR_INSTALANDO'
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def locate(root,rel):
 p=root
 for part in Path(rel).parts:
  if part in ('.','..') or Path(part).is_absolute():raise RuntimeError('Caminho inválido')
  q=p/part
  if not q.exists():
   found=[v for v in p.iterdir() if v.name.casefold()==part.casefold()] if p.is_dir() else []
   if len(found)!=1:raise RuntimeError('Arquivo não encontrado: '+str(q))
   q=found[0]
  p=q
 return p
class Package:
 def __init__(self,path):
  self.z=zipfile.ZipFile(path);self.m=json.loads(self.z.read('manifest.json'))
 def data(self,info):
  b=self.z.read(info['payload'])
  if sha(b)!=info['payload_sha256']:raise RuntimeError('Pacote corrompido: '+info['payload'])
  return b
 def verify(self):
  for info in self.m['files'].values():self.data(info)
def matches(p,info):
 if info['kind']=='literal':return digest(p)==info['target_sha256']
 try:
  with open(p,'rb') as f:
   if f.read(21)!=bytes.fromhex(info['header']):return False
   d=zlib.decompressobj();h=hashlib.sha256();n=0
   while chunk:=f.read(1024*1024):
    raw=d.decompress(chunk);n+=len(raw)
    if n>info['raw_size']:return False
    h.update(raw)
   return d.eof and not d.unused_data and not d.unconsumed_tail and n==info['raw_size'] and h.hexdigest()==info['raw_sha256']
 except (OSError,zlib.error):return False
def state(p,info):
 h=digest(p)
 if h==info['original_sha256']:return 'original'
 if matches(p,info):return 'ptbr'
 if h in info.get('accepted_previous_sha256',[]):return 'anterior'
 return 'diferente'
def prepare_file(pkg,info,original,target):
 fd,tmp=tempfile.mkstemp(prefix=target.name+'.ptbr-',dir=target.parent)
 try:
  with os.fdopen(fd,'wb') as f:
   data=pkg.data(info)
   if info['kind']=='literal':f.write(data)
   else:
    source=zlib.decompress(original.read_bytes()[21:])
    raw=apply(source,data,info['raw_size']);del source,data
    if sha(raw)!=info['raw_sha256']:raise RuntimeError('Reconstrução divergente: '+str(target))
    f.write(bytes.fromhex(info['header']));c=zlib.compressobj(9)
    for i in range(0,len(raw),1024*1024):f.write(c.compress(raw[i:i+1024*1024]))
    f.write(c.flush());del raw
   f.flush();os.fsync(f.fileno())
  if not matches(Path(tmp),info):raise RuntimeError('Falha de integridade: '+str(target))
  return Path(tmp)
 except BaseException:
  Path(tmp).unlink(missing_ok=True);raise
def copy_atomic(src,dst):
 fd,tmp=tempfile.mkstemp(prefix=dst.name+'.restore-',dir=dst.parent)
 try:
  with os.fdopen(fd,'wb') as out,open(src,'rb') as inp:
   shutil.copyfileobj(inp,out,1024*1024);out.flush();os.fsync(out.fileno())
  os.replace(tmp,dst)
 finally:Path(tmp).unlink(missing_ok=True)
def backup_all(root,m,files,states):
 backup=root/BACKUP;backup.mkdir(exist_ok=True)
 for rel,info in m['files'].items():
  dst=backup/rel
  if dst.exists():
   if digest(dst)!=info['original_sha256']:raise RuntimeError('Backup alterado: '+rel)
  elif states[rel]!='original':raise RuntimeError('Falta o backup original de '+rel)
 for rel,info in m['files'].items():
  dst=backup/rel
  if not dst.exists():
   dst.parent.mkdir(parents=True,exist_ok=True);copy_atomic(files[rel],dst)
   if digest(dst)!=info['original_sha256']:raise RuntimeError('Falha no backup de '+rel)
 return backup
def install(root,pkg):
 m=pkg.m;print('Conferindo pacote e instalação...');pkg.verify()
 for rel,h in m['required_originals'].items():
  if digest(locate(root,rel))!=h:raise RuntimeError('Base diferente da verificada: '+rel)
 files={r:locate(root,r) for r in m['files']};states={r:state(p,m['files'][r]) for r,p in files.items()}
 bad=[r for r,s in states.items() if s=='diferente']
 if bad:raise RuntimeError('Arquivos de outra versão/modificação: '+', '.join(bad))
 todo=[r for r,p in files.items() if not matches(p,m['files'][r])]
 need=sum(files[r].stat().st_size for r in files if not (root/BACKUP/r).exists())+max([m['files'][r].get('raw_size',0) for r in todo]+[0])+256*1024*1024
 if shutil.disk_usage(root).free<need:raise RuntimeError('Libere pelo menos %.2f GB para backup e gravação.'%(need/1024**3))
 backup=backup_all(root,m,files,states)
 if not todo:print('Tradução final já presente. Arquivos e backup íntegros; nenhuma reinstalação necessária.');return
 previous={r:files[r].read_bytes() for r in todo if states[r]=='anterior'};written=[]
 try:
  for i,r in enumerate(todo,1):
   print(f'[{i}/{len(todo)}] {r}',flush=True)
   tmp=prepare_file(pkg,m['files'][r],backup/r,files[r])
   os.replace(tmp,files[r]);written.append(r)
   if not matches(files[r],m['files'][r]):raise RuntimeError('Falha após gravação: '+r)
 except BaseException:
  print('Repondo os arquivos anteriores...',flush=True)
  for r in reversed(written):
   if r in previous:
    fd,tmp=tempfile.mkstemp(dir=files[r].parent)
    with os.fdopen(fd,'wb') as f:f.write(previous[r]);f.flush();os.fsync(f.fileno())
    os.replace(tmp,files[r])
   else:copy_atomic(backup/r,files[r])
  raise
 print('\nINSTALAÇÃO CONCLUÍDA. Integridade verificada.')
 print('Backup original: '+str(backup))
 print('Ative Legendas. A validação de todas as missões dentro do jogo permanece pendente; leia COBERTURA.md.')
def restore(root,pkg):
 m=pkg.m;files={r:locate(root,r) for r in m['files']};states={r:state(p,m['files'][r]) for r,p in files.items()};backup=root/BACKUP
 for r,info in m['files'].items():
  if states[r]=='diferente':raise RuntimeError('Arquivo alterado externamente: '+r)
  if not (backup/r).is_file() or digest(backup/r)!=info['original_sha256']:raise RuntimeError('Backup ausente/alterado: '+r)
 old={r:files[r].read_bytes() for r,s in states.items() if s=='anterior'};written=[]
 try:
  for r,p in files.items():
   if states[r]=='original':continue
   copy_atomic(backup/r,p);written.append(r)
   if digest(p)!=m['files'][r]['original_sha256']:raise RuntimeError('Falha ao restaurar '+r)
 except BaseException:
  for r in reversed(written):
   if r in old:
    fd,tmp=tempfile.mkstemp(dir=files[r].parent)
    with os.fdopen(fd,'wb') as f:f.write(old[r])
    os.replace(tmp,files[r])
   else:os.replace(prepare_file(pkg,m['files'][r],backup/r,files[r]),files[r])
  raise
 print('ORIGINAIS RESTAURADOS. Backup mantido.')
def verify(root,pkg):
 ok=True
 for r,info in pkg.m['files'].items():
  s=state(locate(root,r),info);print(r+': '+s);ok &= s!='diferente'
  b=root/BACKUP/r
  if b.exists() and digest(b)!=info['original_sha256']:raise RuntimeError('Backup alterado: '+r)
 if not ok:raise RuntimeError('Há arquivos divergentes.')
 print('Conferência concluída.')
def main():
 parser=argparse.ArgumentParser(description='MW2 PC PT-BR FINAL 1.0 — campanha')
 parser.add_argument('--game');parser.add_argument('--action',choices=['install','restore','verify']);a=parser.parse_args();pkg=Package(Path(sys.argv[0]).resolve())
 print('MW2 (2009) PC — PT-BR FINAL 1.0\nFeche o jogo antes de instalar ou restaurar. Não feche o Termux durante a aplicação.\n')
 root=Path((a.game or input('Pasta que contém iw4sp.exe: ')).strip().strip('"').strip("'")).expanduser().resolve()
 if root.is_file() and root.name.casefold()=='iw4sp.exe':root=root.parent
 if not root.is_dir():raise RuntimeError('Pasta não encontrada: '+str(root))
 action=a.action
 if not action:
  choice=input('1 — Instalar/atualizar\n2 — Restaurar originais\n3 — Verificar\n4 — Sair\nEscolha: ').strip()
  if choice=='4':return
  action={'1':'install','2':'restore','3':'verify'}.get(choice)
  if not action:raise RuntimeError('Opção inválida')
 if action=='verify':verify(root,pkg);return
 lock=root/LOCK
 if lock.exists():
  try:pid=int((lock/'pid').read_text());os.kill(pid,0)
  except ProcessLookupError:(lock/'pid').unlink();lock.rmdir()
  except (OSError,ValueError):raise RuntimeError('Instalação anterior interrompida. Verifique a pasta '+str(lock))
  else:raise RuntimeError('Outro instalador ainda está em execução.')
 lock.mkdir();(lock/'pid').write_text(str(os.getpid()))
 try:
  if action=='install':install(root,pkg)
  else:restore(root,pkg)
 finally:(lock/'pid').unlink(missing_ok=True);lock.rmdir()
if __name__=='__main__':
 try:main()
 except (Exception,KeyboardInterrupt) as e:print('\nNÃO CONCLUÍDO: '+str(e),file=sys.stderr);sys.exit(1)
