# Final 1.0 — escopo e diferenças

Decisão do usuário: entregar como final o conteúdo textual possível, mantendo imagens e vídeos originais. Não incluir multiplayer.

Mudanças em relação à 0.2: identificação do instalador, documentação da instalação única, relatório atualizado e definição do escopo final. Nenhuma mudança nos 24 resultados instalados ou nos 24 payloads. A 0.2 instalada já contém exatamente esta tradução.

O pacote é autossuficiente para aplicação sobre os originais correspondentes; não exige baixar a 0.1 ou a 0.2. Os scripts e registros em fontes são o histórico técnico da construção da base 0.2, não devem ser executados no celular. O instalador é a entrada __main__.py do ZIP.

Limitações aceitas: gráficos, vídeos e áudio originais. Limitações de validação declaradas: cobertura de referências dinâmicas e teste integral de todas as missões. Não há alegação de novas traduções ou de 100% de cobertura nesta consolidação.
