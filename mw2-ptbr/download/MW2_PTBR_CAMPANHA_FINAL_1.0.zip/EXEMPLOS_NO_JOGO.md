# Exemplos para conferir no jogo

São amostras incluídas no pacote. Elas aparecem em momentos diferentes das missões; a presença no arquivo não comprova que todas já foram vistas no jogo. As chaves técnicas abaixo servem apenas para localizar um problema no relatório.

| Arquivo de missão | Exemplo de texto PT-BR |
|---|---|
| trainer.ff | Reagrupe com sua equipe no andar de cima. |
| roadkill.ff | Aguarde o ataque aéreo. |
| cliffhanger.ff | Encontre os caminhões-tanque. |
| airport.ff | Siga as ordens de Makarov. |
| favela.ff | Capture o braço direito de Rojas vivo. |
| invasion.ff | Chegue ao telhado do restaurante Nate's. |
| favela_escape.ff | Dê apoio ao capitão MacTavish enquanto o esquadrão avança até a zona de pouso. |
| arcadia.ff | Recupere as informações na sala segura do número 4677 da Brookmere Road. |
| oilrig.ff | Vá até o heliporto do lado de fora. |
| gulag.ff | Resgate o prisioneiro nº 627. |
| contingency.ff | Siga o capitão Price. |
| dcemp.ff | Lance sinalizadores verdes no telhado. |
| dcburning.ff | Defenda o local da queda. |
| dc_whitehouse.ff | Siga o sargento Foley até Whiskey Hotel. |
| estate.ff | Proteja o DSM até a transferência terminar. |
| boneyard.ff | Chegue ao ponto de encontro. |
| af_caves.ff | Elimine a resistência inimiga. |
| af_chase.ff | Vasculhe o local da queda. |

Além desses objetivos, as legendas de falas estão principalmente em common.ff. Ative Legendas nas opções. O relatório registra 2.190 chaves de diálogo revisadas, incluindo conteúdo legado; não é contagem de falas distintas ou comprovadamente exibidas.

Ao informar um problema, envie a missão e o texto/tela. Isso permite distinguir frase não localizada, texto gráfico, corte de interface e erro de carregamento.
