#!/data/data/com.termux/files/usr/bin/bash
# MW2 2009 PT-BR - JOA00FC - fonte reconstruida localmente do jogo do usuario.
# Nao baixa nenhum arquivo original do Call of Duty.
set -euo pipefail
BASE='https://joa00fc.github.io/mw2-ptbr'
PACKAGE='MW2_PTBR_FONTES_V1.zip'
GAME='/sdcard/X360/Call of Duty - Modern Warfare 2'
WORK="$HOME/mw2-ptbr-builder"
mkdir -p "$WORK"
if [[ ! -f "$GAME/zone/english/common.ff" ]]; then
  echo 'MW2 nao encontrado em /sdcard/X360. Edite a variavel GAME neste script para outra pasta.' >&2
  exit 1
fi
pkg install -y python curl unzip proot-distro qemu-user-i386
curl -fL --retry 3 "$BASE/download/$PACKAGE" -o "$WORK/$PACKAGE"
mkdir -p "$WORK/fonte"
unzip -oq "$WORK/$PACKAGE" -d "$WORK/fonte"
python "$WORK/fonte/REBUILD.py" --pasta "$GAME" --verificar
if [[ "${1:-}" == "--verificar" ]]; then exit 0; fi
if [[ "${1:-}" == "--restaurar" ]]; then
  python "$WORK/fonte/REBUILD.py" --pasta "$GAME" --restaurar
  exit 0
fi
cat <<'EOF'
Instalacao avançada (beta) de arquivos IW4 por emulacao i386 no Termux.
A reconstrução usa o jogo original e pode consumir centenas de MB.
Os hashes devem corresponder exatamente a versão homologada.
EOF
# Por causa das diferencas de glibc/arquiteturas, exigimos um runtime i386
# suportado. Nao tentamos instalar uma distribuicao desconhecida automaticamente.
echo 'BASE CONFERIDA. Para compilar, execute REBUILD.py em Linux x86 com OAT v0.34.0.'
echo 'O instalador automatico nativo Android ainda nao foi homologado.'
