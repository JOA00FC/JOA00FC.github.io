#!/usr/bin/env python3
"""Source-only MW2 IW4 PT-BR rebuild: requires user's original FF files.
Does not ship any copyrighted FastFile. Aborts if hashes mismatch.
"""
from __future__ import annotations
from pathlib import Path
from collections import OrderedDict
import argparse,hashlib,json,re,shutil,subprocess,tempfile,struct,os,sys

HERE=Path(__file__).resolve().parent
GAME_DEFAULT='/sdcard/X360/Call of Duty - Modern Warfare 2'
FILE_NAMES=('common.ff','code_post_gfx.ff','patch.ff')
ORIGINAL={
 'common.ff':'f715f4ca5f2449217979d11d91b163762f7addf00229c43e31ba1c83a10da73f',
 'code_post_gfx.ff':'6f189e840147fe03cec10e3d08c77b7cfbf6cb715c2415f433fd6769b49c1a78',
 'patch.ff':'4739cfba80fa08443bddd4d39898c4ba5a31c8676e50b7675acc4beb633f67d1',
}
TARGET={
 'common.ff':'059733fde8bbb793e2e4e33253360d0b0f55d491e2790690474360eb64cf1f7f',
 'code_post_gfx.ff':'2c3b5fc5fd87eaaa2f7d53099b6b78e5da91dcb1cf3d9127f9a52857cb8e350e',
 'patch.ff':'c012b00499fa7f1295736fba7930ad9c4c845b6b1c556783991ab47210d6abbc',
}
REF=re.compile(r'(?m)^(REFERENCE\s+([A-Za-z0-9_]+)\s*\r?\nLANG_ENGLISH\s+)"((?:\\.|[^"\\])*)"')

# original strings may have encoded literal backslashes; overlay text uses raw OAT escape syntax
def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def checked_copy(src,dst,expected):
 dst.parent.mkdir(parents=True,exist_ok=True)
 temp=dst.with_name(dst.name+'.tmp_mw2ptbr')
 try:
  with open(src,'rb') as f, open(temp,'wb') as o:
   shutil.copyfileobj(f,o,1024*1024)
   o.flush();os.fsync(o.fileno())
  if sha(temp)!=expected:raise RuntimeError('SHA256 de copia invalido: '+str(dst))
  os.replace(temp,dst)
 finally:
  if temp.exists():temp.unlink()

def originals_compatible(folder):
 found={n:sha(folder/n) if (folder/n).is_file() and not (folder/n).is_symlink() else 'ausente' for n in FILE_NAMES}
 print('SHA-256 dos arquivos:', json.dumps(found,indent=2))
 if found==TARGET:return 'installed'
 if found==ORIGINAL:return 'original'
 raise RuntimeError('Sua versao do MW2 nao e a base homologada. Nada foi modificado.\nEste instalador NAO serve para outras versoes; envie os SHA-256 ao mantenedor.')

def merge(local_file,zone,overlays):
 text=local_file.read_bytes().decode('cp1252')
 original={m.group(2):m.group(3) for m in REF.finditer(text)}
 to_replace=overlays[zone]['replace']
 to_remove=set(overlays[zone]['remove'])
 # Block an unknown source zone; no silent accidental removal
 count_before=overlays[zone]['count_before']
 if len(original)!=count_before:raise RuntimeError(f'{zone}: contagem original inesperada ({len(original)} vs {count_before})')
 # Verify all identifiers to remove actually present
 if not to_remove.issubset(original):raise RuntimeError(f'{zone}: identificadores removidos nao encontrados no original')
 found=set()
 def repl(m):
  key=m.group(2);found.add(key)
  if key in to_remove:return ''
  value=to_replace.get(key,m.group(3))
  if '"' in value.replace(r'\"',''):raise RuntimeError('Aspas nao escapadas em '+key)
  return m.group(1)+'"'+value+'"'
 edited=REF.sub(repl,text)
 new_keys={key:v for key,v in to_replace.items() if key not in found}
 # insert before ENDMARKER so final output has exactly expected references
 addition=''.join('\nREFERENCE '+key+'\nLANG_ENGLISH "'+v+'"\n' for key,v in new_keys.items())
 if 'ENDMARKER' not in edited:raise RuntimeError('STR sem ENDMARKER')
 edited=edited.replace('ENDMARKER', addition+'\nENDMARKER',1)
 actual={m.group(2):m.group(3) for m in REF.finditer(edited)}
 if len(actual)!=overlays[zone]['count_after']:
  raise RuntimeError(f'{zone}: contagem final inesperada: {len(actual)}')
 local_file.write_bytes(edited.encode('cp1252'))
 print(zone, 'originais:',len(original),'final:',len(actual),'alterados:',len(to_replace),'removidos:',len(to_remove))

def run(cmd,cwd=None):
 print('COMANDO:', ' '.join(str(x) for x in cmd[:5]), flush=True)
 proc=subprocess.run(cmd,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,errors='replace')
 log=proc.stdout
 if proc.returncode:
  print(log[-3000:])
  raise RuntimeError('OpenAssetTools terminou com erro ('+str(proc.returncode)+')')
 print('\n'.join(log.splitlines()[-3:]))
 return log

def rebuild(game,tools,work,qemu=None,sysroot=None):
 overlays=json.loads((HERE/'sobreposicoes.json').read_text('utf8'))
 oa=Path(tools)
 linker=oa/'Linker';unlinker=oa/'Unlinker'
 if not all(x.is_file() for x in (linker,unlinker)):
  raise RuntimeError('Nao achei Linker e Unlinker em '+str(oa))
 base=game/'zone'/'english'
 tool_prefix=([qemu,'-L',sysroot] if qemu else [])
 # Use relative files inside a workspace so OAT names output zones correctly
 inputs=work/'inputs';inputs.mkdir(parents=True)
 for name in FILE_NAMES:checked_copy(base/name, inputs/name, ORIGINAL[name])
 for name in FILE_NAMES:
  zone=name[:-3];folder=work/('dump_'+zone)
  run(tool_prefix+[str(unlinker),'--no-color','--output-folder',str(folder),str(inputs/name)])
  src=folder/'english'/'localizedstrings'/f'{zone}.str'
  manifest=folder/'zone_source'/f'{zone}.zone'
  if not src.is_file() or not manifest.is_file():raise RuntimeError('Unlinker nao exportou STR/zone de '+zone)
  project='ptbr_'+zone
  dest=work/'zone_raw'/project/'english'/'localizedstrings'/f'{zone}.str'
  dest.parent.mkdir(parents=True,exist_ok=True)
  shutil.copy2(src,dest)
  merge(dest,zone,overlays)
  zone_src=work/'zone_source';zone_src.mkdir(exist_ok=True)
  content=manifest.read_text('utf8')
  if not content.startswith('//'):pass
  content=f'>name,{zone}\n'+content
  (zone_src/(project+'.zone')).write_text(content,encoding='utf8')
  if zone=='common':
   vid=work/'zone_raw'/project/'video'/'subtitles.csv'
   vid.parent.mkdir(parents=True,exist_ok=True)
   shutil.copy2(HERE/'subtitles.csv',vid)
  run(tool_prefix+[str(linker),'--no-color','--base-folder',str(work),'--load',str(inputs/name),project])
  output=work/'zone_out'/project/name
  if not output.exists():raise RuntimeError('Linker nao gerou '+str(output))
  hashout=sha(output)
  print(name,'SHA recompilado',hashout, 'esperado',TARGET[name],flush=True)
  if hashout!=TARGET[name]:
   raise RuntimeError('Recompilacao divergiu no FF '+name+'; nenhuma substituicao foi feita.')
 return {name:work/'zone_out'/('ptbr_'+name[:-3])/name for name in FILE_NAMES}

def main():
 ap=argparse.ArgumentParser(description='MW2 PC IW4: projeto fonte PT-BR JOA00FC')
 ap.add_argument('--pasta',default=GAME_DEFAULT)
 ap.add_argument('--oat',help='Pasta do OpenAssetTools v0.34.0 com Linker e Unlinker')
 ap.add_argument('--qemu',default=None)
 ap.add_argument('--sysroot',default=None)
 group=ap.add_mutually_exclusive_group(required=True)
 group.add_argument('--verificar',action='store_true')
 group.add_argument('--instalar',action='store_true')
 group.add_argument('--restaurar',action='store_true')
 args=ap.parse_args()
 game=Path(args.pasta).expanduser().resolve(); base=game/'zone'/'english'
 if not base.is_dir():raise RuntimeError('Nao encontrei zone/english nesta pasta: '+str(base))
 backup=game/'MW2_PTBR_BACKUP_PUBLICO_V1'
 if args.restaurar:
  if not backup.is_dir():raise RuntimeError('Nenhum backup desta ferramenta encontrado')
  for name in FILE_NAMES:
   file=backup/(name+'.bak')
   if not file.is_file() or sha(file)!=ORIGINAL[name]:raise RuntimeError('Backup invalido: '+name)
  state=originals_compatible(base)
  if state=='original':print('Os FFs originais ja estao ativos');return
  for name in FILE_NAMES:checked_copy(backup/(name+'.bak'),base/name,ORIGINAL[name])
  print('Restauracao concluida.');return
 state=originals_compatible(base)
 if args.verificar:
  print('Instalado' if state=='installed' else 'Base original compativel.');return
 if state=='installed':
  print('A traducao ja esta instalada.');return
 if not args.oat:raise RuntimeError('Informe --oat com OpenAssetTools v0.34.0.')
 space_needed=850*1024*1024
 if shutil.disk_usage(game).free<space_needed:raise RuntimeError('Espaco livre insuficiente; precisa de ~850 MB para staging e backup.')
 with tempfile.TemporaryDirectory(prefix='mw2_ptbr_build_') as tmp:
  sources=rebuild(game,args.oat,Path(tmp),args.qemu,args.sysroot)
  for name in FILE_NAMES:
   b=backup/(name+'.bak')
   if b.exists():
    if sha(b)!=ORIGINAL[name]:raise RuntimeError('Backup existente inesperado em '+str(b))
   else:checked_copy(base/name,b,ORIGINAL[name])
  stage=backup/'stage'
  try:
   for name in FILE_NAMES:checked_copy(sources[name],stage/name,TARGET[name])
   for name in FILE_NAMES:checked_copy(stage/name,base/name,TARGET[name])
  except BaseException:
   print('Erro: restaurando backups',file=sys.stderr)
   for name in FILE_NAMES:checked_copy(backup/(name+'.bak'),base/name,ORIGINAL[name])
   raise
  finally:
   if stage.exists():shutil.rmtree(stage)
 print('Instalacao concluida. Os 3 FFs estao traduzidos; backups:',backup)
 print('A traducao so foi testada ate agora no GameHub com essa base de arquivos.')

if __name__=='__main__':
 try:main()
 except Exception as e:
  print('INSTALACAO BLOQUEADA:',e,file=sys.stderr)
  sys.exit(1)
